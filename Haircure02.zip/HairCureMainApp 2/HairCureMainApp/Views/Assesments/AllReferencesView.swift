////
////  AllReferencesView.swift
////  HairCure
////
////  Shows all peer-reviewed research references grouped by topic.
////  Used on the Scan Report screen to surface the full evidence base.
////
//
//import SwiftUI
//
//// MARK: - Data Model
//
//private struct Reference: Identifiable {
//    let id = UUID()
//    let citation: String
//    let urlString: String
//}
//
//private struct ReferenceGroup: Identifiable {
//    let id = UUID()
//    let topic: String
//    let icon: String
//    let references: [Reference]
//}
//
//// MARK: - View
//
//struct AllReferencesView: View {
//    @Environment(\.dismiss) private var dismiss
//
//    var body: some View {
//        NavigationStack {
//            ScrollView(showsIndicators: false) {
//                VStack(alignment: .leading, spacing: 20) {
//
//                    Text("The science behind your personalised hair plan.")
//                        .font(.system(size: 15, weight: .medium))
//                        .foregroundStyle(.secondary)
//                        .padding(.horizontal, 20)
//                        .padding(.top, 4)
//
//                    ForEach(allGroups) { group in
//                        VStack(alignment: .leading, spacing: 14) {
//                            HStack(spacing: 10) {
//                                Image(systemName: group.icon)
//                                    .font(.system(size: 16, weight: .semibold))
//                                    .foregroundStyle(.white)
//                                    .frame(width: 32, height: 32)
//                                    .background(Color.hcBrown)
//                                    .clipShape(RoundedRectangle(cornerRadius: 8))
//
//                                Text(group.topic)
//                                    .font(.system(size: 18, weight: .bold))
//                            }
//
//                            VStack(alignment: .leading, spacing: 12) {
//                                ForEach(group.references) { ref in
//                                    VStack(alignment: .leading, spacing: 6) {
//                                        Text(ref.citation)
//                                            .font(.system(size: 13))
//                                            .foregroundStyle(.primary.opacity(0.85))
//                                            .fixedSize(horizontal: false, vertical: true)
//
//                                        if let url = URL(string: ref.urlString) {
//                                            Link(destination: url) {
//                                                HStack(spacing: 4) {
//                                                    Image(systemName: "link")
//                                                        .font(.system(size: 11))
//                                                    Text("View Paper")
//                                                        .font(.system(size: 13, weight: .medium))
//                                                }
//                                                .foregroundStyle(Color.hcBrown)
//                                            }
//                                        }
//                                    }
//
//                                    if ref.id != group.references.last?.id {
//                                        Divider()
//                                    }
//                                }
//                            }
//                        }
//                        .padding(16)
//                        .background(Color.white)
//                        .clipShape(RoundedRectangle(cornerRadius: 16))
//                        .shadow(color: .black.opacity(0.04), radius: 6, y: 2)
//                        .padding(.horizontal, 20)
//                    }
//                }
//                .padding(.bottom, 40)
//            }
//            .background(Color.hcCream.ignoresSafeArea())
//            .navigationTitle("Research Basis")
//            .navigationBarTitleDisplayMode(.large)
//            .toolbar {
//                ToolbarItem(placement: .topBarTrailing) {
//                    Button {
//                        dismiss()
//                    } label: {
//                        Image(systemName: "xmark.circle.fill")
//                            .font(.system(size: 22))
//                            .symbolRenderingMode(.hierarchical)
//                            .foregroundStyle(.secondary)
//                    }
//                }
//            }
//        }
//        .presentationDetents([.medium, .large])
//    }
//
//    // MARK: - All Reference Groups
//
//    private var allGroups: [ReferenceGroup] {
//        [
//            ReferenceGroup(
//                topic: "Hair Fall Stage — Hamilton–Norwood Scale",
//                icon: "person.text.rectangle",
//                references: [
//                    Reference(
//                        citation: "Hamilton JB. (1951). Patterned loss of hair in man: types and incidence. Annals of the New York Academy of Sciences, 53(3), 708–728.",
//                        urlString: "https://doi.org/10.1111/j.1749-6632.1951.tb31971.x"
//                    ),
//                    Reference(
//                        citation: "Norwood OT. (1975). Male pattern baldness: classification and incidence. Southern Medical Journal, 68(11), 1359–1365.",
//                        urlString: "https://doi.org/10.1097/00007611-197511000-00009"
//                    ),
//                ]
//            ),
//            ReferenceGroup(
//                topic: "Sleep & Hair Growth",
//                icon: "moon.zzz.fill",
//                references: [
//                    Reference(
//                        citation: "Buysse DJ, Reynolds CF, Monk TH, Berman SR, Kupfer DJ. (1989). The Pittsburgh Sleep Quality Index. Psychiatry Research, 28(2), 193–213.",
//                        urlString: "https://doi.org/10.1016/0165-1781(89)90047-4"
//                    ),
//                    Reference(
//                        citation: "Trüeb RM. (2015). Effect of ultraviolet radiation, smoking and nutrition on hair. Current Problems in Dermatology, 47, 107–120.",
//                        urlString: "https://doi.org/10.1159/000369596"
//                    ),
//                ]
//            ),
//            ReferenceGroup(
//                topic: "Stress & Hair Loss",
//                icon: "brain.head.profile",
//                references: [
//                    Reference(
//                        citation: "Cohen S, Kamarck T, Mermelstein R. (1983). A global measure of perceived stress. Journal of Health and Social Behavior, 24(4), 385–396.",
//                        urlString: "https://doi.org/10.2307/2136404"
//                    ),
//                    Reference(
//                        citation: "Peters EMJ, et al. (2006). Stress exposure modulates peptidergic innervation and degranulates mast cells in murine skin. Brain, Behavior, and Immunity, 20(6), 624–634.",
//                        urlString: "https://doi.org/10.1016/j.bbi.2006.01.001"
//                    ),
//                ]
//            ),
//            ReferenceGroup(
//                topic: "Diet & Hair Health",
//                icon: "leaf.fill",
//                references: [
//                    Reference(
//                        citation: "Almohanna HM, et al. (2019). The role of vitamins and minerals in hair loss: a review. Dermatology and Therapy, 9(1), 51–70.",
//                        urlString: "https://doi.org/10.1007/s13555-018-0278-6"
//                    ),
//                    Reference(
//                        citation: "Rushton DH. (2002). Nutritional factors and hair loss. Clinical and Experimental Dermatology, 27(5), 396–404.",
//                        urlString: "https://doi.org/10.1046/j.1365-2230.2002.01076.x"
//                    ),
//                ]
//            ),
//            ReferenceGroup(
//                topic: "Hydration",
//                icon: "drop.fill",
//                references: [
//                    Reference(
//                        citation: "EFSA Panel on Dietetic Products, Nutrition, and Allergies. (2010). Scientific Opinion on Dietary Reference Values for water. EFSA Journal, 8(3), 1459.",
//                        urlString: "https://doi.org/10.2903/j.efsa.2010.1459"
//                    ),
//                ]
//            ),
//            ReferenceGroup(
//                topic: "Hair Care Practices",
//                icon: "comb.fill",
//                references: [
//                    Reference(
//                        citation: "Ranganathan S, Mukhopadhyay T. (2010). Dandruff: the most commercially exploited skin disease. Indian Journal of Dermatology, 55(2), 130–134.",
//                        urlString: "https://doi.org/10.4103/0019-5154.62734"
//                    ),
//                    Reference(
//                        citation: "Trüeb RM. (2007). Shampoos: ingredients, efficacy and adverse effects. Journal der Deutschen Dermatologischen Gesellschaft, 5(5), 356–365.",
//                        urlString: "https://doi.org/10.1111/j.1610-0387.2007.06304.x"
//                    ),
//                ]
//            ),
//            ReferenceGroup(
//                topic: "BMR & Nutritional Targets",
//                icon: "flame.fill",
//                references: [
//                    Reference(
//                        citation: "Mifflin MD, St Jeor ST, et al. (1990). A new predictive equation for resting energy expenditure in healthy individuals. American Journal of Clinical Nutrition, 51(2), 241–247.",
//                        urlString: "https://doi.org/10.1093/ajcn/51.2.241"
//                    ),
//                ]
//            ),
//        ]
//    }
//}

//
//  AllReferencesView.swift
//  HairCure
//
//  Shows all peer-reviewed research references grouped by topic.
//  Used on the Scan Report screen to surface the full evidence base.
//

import SwiftUI

// MARK: - Data Model

private struct Reference: Identifiable {
    let id = UUID()
    let citation: String
    let urlString: String
}

private struct ReferenceGroup: Identifiable {
    let id = UUID()
    let topic: String
    let icon: String
    let references: [Reference]
}

// MARK: - View

struct AllReferencesView: View {
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 20) {

                    Text("The science behind your personalised hair plan.")
                        .font(.system(size: 15, weight: .medium))
                        .foregroundStyle(.secondary)
                        .padding(.horizontal, 20)
                        .padding(.top, 4)

                    ForEach(allGroups) { group in
                        VStack(alignment: .leading, spacing: 14) {
                            HStack(spacing: 10) {
                                Image(systemName: group.icon)
                                    .font(.system(size: 16, weight: .semibold))
                                    .foregroundStyle(.white)
                                    .frame(width: 32, height: 32)
                                    .background(Color.hcBrown)
                                    .clipShape(RoundedRectangle(cornerRadius: 8))

                                Text(group.topic)
                                    .font(.system(size: 18, weight: .bold))
                            }

                            VStack(alignment: .leading, spacing: 12) {
                                ForEach(group.references) { ref in
                                    VStack(alignment: .leading, spacing: 6) {
                                        Text(ref.citation)
                                            .font(.system(size: 13))
                                            .foregroundStyle(.primary.opacity(0.85))
                                            .fixedSize(horizontal: false, vertical: true)

                                        if let url = URL(string: ref.urlString) {
                                            Link(destination: url) {
                                                HStack(spacing: 4) {
                                                    Image(systemName: "link")
                                                        .font(.system(size: 11))
                                                    Text("View Paper")
                                                        .font(.system(size: 13, weight: .medium))
                                                }
                                                .foregroundStyle(Color.hcBrown)
                                            }
                                        }
                                    }

                                    if ref.id != group.references.last?.id {
                                        Divider()
                                    }
                                }
                            }
                        }
                        .padding(16)
                        .background(Color.white)
                        .clipShape(RoundedRectangle(cornerRadius: 16))
                        .shadow(color: .black.opacity(0.04), radius: 6, y: 2)
                        .padding(.horizontal, 20)
                    }
                }
                .padding(.bottom, 40)
            }
            .background(Color.hcCream.ignoresSafeArea())
            .navigationTitle("Research Basis")
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "xmark.circle.fill")
                            .font(.system(size: 22))
                            .symbolRenderingMode(.hierarchical)
                            .foregroundStyle(.secondary)
                    }
                }
            }
        }
        .presentationDetents([.medium, .large])
    }

    // MARK: - All Reference Groups

    private var allGroups: [ReferenceGroup] {
        [
            ReferenceGroup(
                topic: "Sleep",
                icon: "moon.zzz.fill",
                references: [
                    Reference(
                        citation: "Boghosian T, Mendez H, Sayegh M, et al. The intersection of sleep and hair loss: a systematic review. Dermatol Ther (Heidelb). 2026; PMID: 41535530.",
                        urlString: "https://pubmed.ncbi.nlm.nih.gov/41535530/"
                    ),
                ]
            ),
            ReferenceGroup(
                topic: "Stress",
                icon: "brain.head.profile",
                references: [
                    Reference(
                        citation: "National Institutes of Health (NIH). (2021, April 13). How stress causes hair loss",
                        urlString: "https://www.nih.gov/news-events/nih-research-matters/how-stress-causes-hair-loss"
                    ),
                ]
            ),
            ReferenceGroup(
                topic: "Diet",
                icon: "leaf.fill",
                references: [
                    Reference(
                        citation: "Guo EL, Katta R. Diet and hair loss: effects of nutrient deficiency and supplement use. Dermatol Pract Concept. 2017;7(1):1–10. PMCID: PMC5315033; PMID: 28243487",
                        urlString: "https://pmc.ncbi.nlm.nih.gov/articles/PMC5315033/"
                    ),
                ]
            ),
//            ReferenceGroup(
//                topic: "Hydration — EFSA 2010",
//                icon: "drop.fill",
//                references: [
//                    Reference(
//                        citation: "EFSA Panel on Dietetic Products, Nutrition, and Allergies. (2010). Scientific Opinion on Dietary Reference Values for water. EFSA Journal, 8(3), 1459.",
//                        urlString: "https://doi.org/10.2903/j.efsa.2010.1459"
//                    ),
//                ]
//            ),
//            ReferenceGroup(
//                topic: "Hair Care — Ranganathan 2010 + Trüeb",
//                icon: "comb.fill",
//                references: [
//                    Reference(
//                        citation: "Ranganathan S, Mukhopadhyay T. (2010). Dandruff: the most commercially exploited skin disease. Indian Journal of Dermatology, 55(2), 130–134.",
//                        urlString: "https://doi.org/10.4103/0019-5154.62734"
//                    ),
//                    Reference(
//                        citation: "Trüeb RM. (2007). Shampoos: ingredients, efficacy and adverse effects. Journal der Deutschen Dermatologischen Gesellschaft, 5(5), 356–365.",
//                        urlString: "https://doi.org/10.1111/j.1610-0387.2007.06304.x"
//                    ),
//                ]
//            ),
//            ReferenceGroup(
//                topic: "Telogen Effluvium Mechanism",
//                icon: "waveform.path.ecg",
//                references: [
//                    Reference(
//                        citation: "Peters EMJ, et al. (2006). Neurogenic inflammation in stress-induced termination of murine hair growth is mediated by substance P. American Journal of Pathology, 169(6), 1978–1990.",
//                        urlString: ""
//                    ),
//                ]
//            ),
//            ReferenceGroup(
//                topic: "BMR Formula",
//                icon: "flame.fill",
//                references: [
//                    Reference(
//                        citation: "Cleveland Clinic. (2024, November 20). Basal metabolic rate (BMR): What it is & how to calculate it",
//                        urlString: ""
//                    ),
//                ]
            
        ]
    }
}
